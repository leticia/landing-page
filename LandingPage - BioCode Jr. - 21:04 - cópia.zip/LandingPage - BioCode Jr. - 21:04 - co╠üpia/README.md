# Landing Page Clínica
Projeto da landing page de uma clínica para a @biocodejr.

### Design escolhido
[Design](https://dribbble.com/shots/21103043-Website-UI)

### Fontes, ícones e gráficos

1. Fonte: Inter (/fonts)
2. Ícones: [medical
   pack](https://www.iconfinder.com/iconsets/medical-line-33), [font
   awesome](https://www.iconfinder.com/search/icons?family=font-awesome-regular)
   e [feather](https://www.iconfinder.com/search/icons?family=feather) -
   fiquem livres pra sugerir mais, caso necessário
3. Fotos: Unsplash
   [clinic](https://unsplash.com/pt-br/s/fotografias/clinic) e
   [medical](https://unsplash.com/pt-br/s/fotografias/medical)
